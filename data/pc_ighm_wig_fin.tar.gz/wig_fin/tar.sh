mkdir temp_dir
cd temp_dir
ls ../pc_fin_* | sort -V | head -n 50 | xargs -I {} cp {} .
tar -czvf ../pc.tar.gz .
cd ..
rm -rf temp_dir
